Ensemble d'icônes
=================

Dans ce dossier, on va pouvoir stocker l'ensemble des icônes et informations qui serviront à identifier le site ou l'application.

Vous pouvez utiliser l'outil suivant pour les générer facilement : http://realfavicongenerator.net/, en uploadant une image carrée, au format PNG, d'au mois 260px de côté.