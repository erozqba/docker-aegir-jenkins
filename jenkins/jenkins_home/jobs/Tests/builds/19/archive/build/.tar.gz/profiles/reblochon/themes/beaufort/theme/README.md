Surcharge des fonctions de thème
================================

Au lieu de surcharger les fonctions de thèmes dans le fichier template.php, Beaufort  vous permet de les séparer dans des fichiers inclus automatiquement. Ces fichiers doivent respecter le même modèle de nom que les fichiers de (pre)process pour être chargés automatiquement quand le thème est utilisé.

Cette fonctionnalité améliore grandement la maintenabilité des grands thèmes qui contiendrait autrement des centaines de lignes de code dans le fichier template.php.

Les fichiers à inclure doivent respecter un certain modèle (HOOK.theme.inc) afin d'être chargé automatiquement :

* THEMENAME_breadcrumb() = breadcrumb.theme.inc
* THEMENAME_button() = button.theme.inc

Comme pour les fichiers de templates, vous devriez remplacer les underscores par des tirets :

* THEMENAME_status_messages() = status-messages.theme.inc
* THEMENAME_menu_link() = menu-link.theme.inc

Dans chacun de ces fichiers, vus pouvez sur charger la fonction de thème comme vous le feriez dans le fichier template.php.

```
function THEMENAME_HOOK(&$variables) {
  // Your code here.
}
```

Par exemple :

```
function THEMENAME_menu_link(&$variables) {
  // Your code here.
}
```
