Dossier des CSS
===============

Pour ajouter un fichier CSS au thème, il suffit d'ajouter une ligne dans le fichier .info :

    stylesheets[all][]  = css/styles.css

Le mot-clé _all_ peut être remplacé par _print_, ou _mobile_ par exemple.

Le chemin du fichier est relatif à la racine du thème.
