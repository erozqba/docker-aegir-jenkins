Définition des hooks de process
===============================

Plutôt que de placer directement vos hooks de process dans le fichier template.php vous pouvez les implémenter dans des fichiers dédiés qui seront chargés automatiquement.
C'est même possible de les organiser en sous-répertoires.
Cette fonctionnalité améliore grandement la maintenabilité des grands thèmes qui contiendrait autrement des centaines de lignes de code dans le fichier template.php.

Les fichiers à inclure doivent respecter un certain modèle (HOOK.process.inc) afin d'être chargé automatiquement :

* THEMENAME_process_html() = html.process.inc
* THEMENAME_process_page() = page.process.inc
* THEMENAME_process_node() = node.process.inc
* THEMENAME_process_comment() = comment.process.inc
* THEMENAME_process_region() = region.process.inc

Comme pour les fichiers de templates, vous devriez remplacer les underscores par des tirets :

* THEMENAME_process_comment_wrapper() = comment-wrapper.process.inc
* THEMENAME_process_html_tag() = html-tag.process.inc

Dans chacun de ces fichiers, vous pouvez implémenter le hook de process comme vous le feriez dans le fichier template.php.

```
<?php

/**
 * @file
 * Contains a process hook for 'html'.
 */

/**
 * Implements hook_process_html().
 */
function THEMENAME_process_html(&$variables) {
  // Your code here.
}
```

Cas des nodes et des termes de taxonomie
----------------------------------------

Les nodes et les termes de taxonomie bénéficient d'un traitement spécial, afin de ne pas regrouper toutes les traitements dans la même fonction de process.
Des fonctions plus ciblées sont disponibles en fonction du type du node (vocabulaire pour le terme) et du viewmode courant, et en dernier recours de l'ID (NID pour les nodes, TID pour les termes de taxonomie).

Ces fonctions sont appelées via le process de base de ces entités et peuvent être adaptées à d'autres entités comme les _users_.

Dans le cas des nodes :

* Process pour tous les nodes = beaufort_process_node(&$variables)
* Process pour tous les nodes de type _article_ = beaufort_process_node__article(&$variables)
* Process pour tous les nodes affichés dans le viewmode _teaser_ = beaufort_process_node__teaser(&$variables)
* Process pour tous les nodes de type _article_, affichés dans le viewmode _teaser_ = beaufort_process_node\_\_article\_\_teaser(&$variables)

Dans le cas des termes de taxonomie :

* Process pour tous les termes = beaufort_process_taxonomy_term(&$variables)
* Process pour tous les termes du vocabulaire _tag_ = beaufort_process_taxonomy_term__tag(&$variables)
* Process pour tous les termes affichés dans le viewmode _teaser_ = beaufort_process_taxonomy_term__teaser(&$variables)
* Process pour tous les termes du vocabulaire _tag_, affichés dans le viewmode _teaser_ = beaufort_process_taxonomy_term\_\_article\_\_teaser(&$variables)