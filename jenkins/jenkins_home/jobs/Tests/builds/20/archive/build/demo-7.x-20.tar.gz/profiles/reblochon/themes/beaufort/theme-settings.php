<?php

/**
 * @file
 * Theme settings file for the beaufort theme.
 */

/**
 * Implements hook_form_FORM_alter().
 */
function beaufort_form_system_theme_settings_alter(&$form, $form_state) {
  $key = arg(3);

  // Re-order default favicon settings
  $form['favicon']['default_favicon']['#weight'] = 0;
  unset($form['favicon']['settings']['favicon_path']);
  unset($form['favicon']['settings']['favicon_upload']);

  // Icons folder path
  $form['favicon']['settings']['icons_folder'] = array(
    '#type' => 'textfield',
    '#title' => t('Path to icons folder.'),
    '#description' => t('Relative to theme path, without trailing slashes.'),
    '#default_value' => theme_get_setting('icons_folder', $key),
    '#weight' => 3,
  );

  // Which icons should be displayed
  $value = (theme_get_setting('rendered_icons', $key)) ? theme_get_setting('rendered_icons', $key) : array();
  $form['favicon']['settings']['rendered_icons'] = array(
    '#type' => 'checkboxes',
    '#title' => t('Icons to render'),
    '#options' => array(
      'basic_favicon'   => 'Basic favicon',
      'apple_57'        => 'Apple touch icon 57x57',
      'apple_60'        => 'Apple touch icon 60x60',
      'apple_72'        => 'Apple touch icon 72x72',
      'apple_76'        => 'Apple touch icon 76x76',
      'apple_114'       => 'Apple touch icon 114x114',
      'apple_120'       => 'Apple touch icon 120x120',
      'apple_144'       => 'Apple touch icon 144x144',
      'apple_152'       => 'Apple touch icon 152x152',
      'apple_180'       => 'Apple touch icon 180x180',
      'icon_16'         => 'PNG Favicon 16x16',
      'icon_32'         => 'PNG Favicon 32x32',
      'icon_96'         => 'PNG Favicon 96x96',
      'icon_192'        => 'Andoird Chrome Icon 192x192',
      'google_manifest' => 'Google JSON manifest',
      'ms_tile_color'   => 'MSapplication tileColor',
      'ms_tile_image'   => 'MSapplication tileImage',
      'ms_config'       => 'MSapplication config',
      'theme_color'     => 'Theme color',
    ),
    '#default_value' => $value,
    '#weight' => 4,
  );

  // Color code for MS Tiles
  $form['favicon']['settings']['ms_tile_color_meta'] = array(
    '#type' => 'textfield',
    '#field_prefix' => '#',
    '#title' => t('<strong>msapplication-TileColor</strong> meta tag content.'),
    '#description' => t('Hexadecimal code.'),
    '#default_value' => theme_get_setting('ms_tile_color_meta', $key),
    '#weight' => 5,
  );

  // Color code for theme-color tag
  $form['favicon']['settings']['theme_color_meta'] = array(
    '#type' => 'textfield',
    '#field_prefix' => '#',
    '#title' => t('<strong>theme-color</strong> meta tag content.'),
    '#default_value' => theme_get_setting('theme_color_meta', $key),
    '#weight' => 6,
  );
}
