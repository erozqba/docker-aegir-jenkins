Définition des hooks de preprocess
==================================

Plutôt que de placer directement vos hooks de preprocess dans le fichier template.php vous pouvez les implémenter dans des fichiers dédiés qui seront chargés automatiquement.
C'est même possible de les organiser en sous-répertoires.
Cette fonctionnalité améliore grandement la maintenabilité des grands thèmes qui contiendrait autrement des centaines de lignes de code dans le fichier template.php.

Les fichiers à inclure doivent respecter un certain modèle (HOOK.preprocess.inc) afin d'être chargé automatiquement :

* THEMENAME_preprocess_html() = html.preprocess.inc
* THEMENAME_preprocess_page() = page.preprocess.inc
* THEMENAME_preprocess_node() = node.preprocess.inc
* THEMENAME_preprocess_comment() = comment.preprocess.inc
* THEMENAME_preprocess_region() = region.preprocess.inc

Comme pour les fichiers de templates, vous devriez remplacer les underscores par des tirets :

* THEMENAME_preprocess_comment_wrapper() = comment-wrapper.preprocess.inc
* THEMENAME_preprocess_html_tag() = html-tag.preprocess.inc


Dans chacun de ces fichiers, vous pouvez implémenter le hook de preprocess comme vous le feriez dans le fichier template.php.

```
<?php

/**
 * @file
 * Contains a pre-process hook for 'html'.
 */

/**
 * Implements hook_preprocess_html().
 */
function THEMENAME_preprocess_html(&$variables) {
  // Your code here.
}
```

Cas des nodes et des termes de taxonomie
----------------------------------------

Les nodes et les termes de taxonomie bénéficient d'un traitement spécial, afin de ne pas regrouper toutes les traitements dans la même fonction de preprocess.
Des fonctions plus ciblées sont disponibles en fonction du type du node (vocabulaire pour le terme) et du viewmode courant, et en dernier recours de l'ID (NID pour les nodes, TID pour les termes de taxonomie).

Ces fonctions sont appelées via le preprocess de base de ces entités et peuvent être adaptées à d'autres entités comme les _users_.

Dans le cas des nodes :

* Preprocess pour tous les nodes = beaufort_preprocess_node(&$variables)
* Preprocess pour tous les nodes de type _article_ = beaufort_preprocess_node__article(&$variables)
* Preprocess pour tous les nodes affichés dans le viewmode _teaser_ = beaufort_preprocess_node__teaser(&$variables)
* Preprocess pour tous les nodes de type _article_, affichés dans le viewmode _teaser_ = beaufort_preprocess_node\_\_article\_\_teaser(&$variables)

Dans le cas des termes de taxonomie :

* Preprocess pour tous les termes = beaufort_preprocess_taxonomy_term(&$variables)
* Preprocess pour tous les termes du vocabulaire _tag_ = beaufort_preprocess_taxonomy_term__tag(&$variables)
* Preprocess pour tous les termes affichés dans le viewmode _teaser_ = beaufort_preprocess_taxonomy_term__teaser(&$variables)
* Preprocess pour tous les termes du vocabulaire _tag_, affichés dans le viewmode _teaser_ = beaufort_preprocess_taxonomy_term\_\_article\_\_teaser(&$variables)