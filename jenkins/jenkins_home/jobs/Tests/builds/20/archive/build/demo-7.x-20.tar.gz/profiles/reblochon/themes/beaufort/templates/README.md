Surcharge des fichiers de templates
===================================

Copiez dans ce répertoire les fichiers des templates que vous voulez surcharger.
Vous pouvez aussi les ranger dans des sous-répertoires.

Cas des nodes et des termes de taxonomie
----------------------------------------

Les nodes et les termes de taxonomie bénéficient d'un traitement spécial.
Des templates de plus en plus ciblés peuvent être utilisés pour obtenir un markup différent selon le type du noeud (vocabulaire pour le terme) ou encore le viewmode utilisé pour le rendu.

Cette suggestion de template est faite via le hook de preprocess dédié. Elle peut être reprise et adaptée pour d'autres entités, comme les users.

Dans le cas des nodes (le premier étant surchargé par le deuxième, et ainsi de suite) :

* Template pour tous les nodes = *node.tpl.php*
* Template pour tous les nodes de type _article_ = node--article.tpl.php
* Template pour tous les nodes affichés dans le viewmode _teaser_ = node--teaser.tpl.php
* Template pour tous les nodes de type _article_, affichés dans le viewmode _teaser_ = node--article--teaser.tpl.php
* Template pour le node dont l'ID est 86 = node--86.tpl.php

Dans le cas des termes de taxonomie (le premier étant surchargé par le deuxième, et ainsi de suite) :

* Template pour tous les termes = taxonomy-term.tpl.php
* Template pour tous les termes du vocabulaire _tag_ = taxonomy-term--tag.tpl.php
* Template pour tous les termes affichés dans le viewmode _teaser_ = taxonomy-term--teaser.tpl.php
* Template pour tous les termes du vocabulaire _tag_, affichés dans le viewmode _teaser_ = taxonomy-term--tag--teaser.tpl.php
* Template pour le termes dont l'ID est 77 = taxonomy-term--77.tpl.php