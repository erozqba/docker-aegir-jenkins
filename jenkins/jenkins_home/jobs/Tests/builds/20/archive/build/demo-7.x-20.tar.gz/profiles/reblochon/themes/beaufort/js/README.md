Dossier des JS
==============

Pour ajouter un fichier JS au thème, il suffit d'ajouter une ligne dans le fichier .info :

    scripts[] = js/scripts.js

Le chemin du fichier est relatif à la racine du thème.

Il est fortement recommandé de mettre le code JS dans des _behaviors_ ou dans des fonctions de thème JS. Vous pouvez lire les commentaires explicatifs dans le fichier _scripts.js_.
