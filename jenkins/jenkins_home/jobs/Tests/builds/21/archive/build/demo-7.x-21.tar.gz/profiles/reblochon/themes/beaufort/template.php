<?php

/**
 * @file
 * This file contains the main theme functions hooks and overrides.
 */

require_once dirname(__FILE__) . '/includes/utils.inc';

/**
 * Implements hook_theme_registry_alter().
 */
function beaufort_theme_registry_alter(&$registry) {

  // Call theme registry handler
  require_once dirname(__FILE__) . '/includes/registry.inc';
  $handler = new BeaufortThemeRegistryHandler($registry, $GLOBALS['theme']);

  // Allows themers to split preprocess / process / theme code across separate
  // files to keep the main template.php file clean. This is really fast because
  // it uses the theme registry to cache the paths to the files that it finds.
  $trail = beaufort_theme_trail($GLOBALS['theme']);
  foreach ($trail as $theme => $name) {
    $handler->registerHooks($theme);
    $handler->registerThemeFunctions($theme, $trail);
  }
}

/**
 * Implements hook_theme()
 */
function beaufort_theme() {
  return array(

    // Custom theming for menus
    'sfl_menu' => array(),
  );
}
